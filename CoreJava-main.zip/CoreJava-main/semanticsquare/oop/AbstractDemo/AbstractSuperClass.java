package com.semanticsquare.oop.AbstractDemo;

public abstract class AbstractSuperClass {
	    abstract void test1();
	    abstract void test2();
	}
