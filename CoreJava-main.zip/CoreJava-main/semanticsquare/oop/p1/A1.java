package com.semanticsquare.oop.p1;

public class A1 {
	  static private int privateMember = 1;
	  static int defaultMember = 2;
	  static protected int protectedMember = 3;
	  static public int publicMember = 4;  
}
