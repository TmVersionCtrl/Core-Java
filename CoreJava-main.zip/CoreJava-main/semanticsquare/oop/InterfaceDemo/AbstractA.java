package com.semanticsquare.oop.InterfaceDemo;

public abstract class AbstractA implements A {
	   public void bar() {
		   System.out.println("AbstractA: bar");
	   }
	}
