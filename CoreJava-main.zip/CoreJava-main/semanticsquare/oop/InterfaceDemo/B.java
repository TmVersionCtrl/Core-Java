package com.semanticsquare.oop.InterfaceDemo;

public interface B {
	   int VAL = TestClient.getVal();
	   void foo();
	}
