package com.semanticsquare.oop.InterfaceDemo;

public interface C extends A {
	   void foobar();
	}