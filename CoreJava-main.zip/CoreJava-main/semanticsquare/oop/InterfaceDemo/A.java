package com.semanticsquare.oop.InterfaceDemo;

public interface A {
	int VAL=5;  	//static and final variable.
	void foo();		//public and abstract by default.
	void bar();
}
