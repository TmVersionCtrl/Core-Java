package com.semanticsquare.oop.p2;
import com.semanticsquare.oop.p1.A1;

public class C2 extends A1 {
	public static void main(String[] args) {
		//System.out.println("privateMember: " + privateMember);
		//System.out.println("defaultMember: " + defaultMember);
		System.out.println("protectedMember: " + protectedMember);
		System.out.println("publicMember: " + publicMember);
	}
}
