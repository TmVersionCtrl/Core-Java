# Java In Depth By Sir Dheeru Mundluru
This was intensive course from Udemy which deals with how **Java** evolving as a language and why was it necessary to do so like ex:how Scala integrated **FP** and **OOPs**, 
seeing this Java introduced **FP** aka **Lambda's & Streams** from Java 8.
Also some of the data is taken from different youtube channels like **Jacob Jenkov** and **kody simpson**.
