package com.semanticssquare.basics;

public class User {
	public void printUserType() {
		System.out.println("User");
	}
	
	public void saveWebLink() {
		System.out.println("User:saveWebLink");
	}
	
	public void postAReview() {
		System.out.println("User:postAReview");
	}
}
